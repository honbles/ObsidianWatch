#!/usr/bin/env bash
# Run eShopOnWeb (the Web app) instrumented for ObsidianWatch (.NET, Tier 2).
#
#   ./run.sh                 build if needed, start on a random free port on 0.0.0.0 (in-memory database)
#   OW_DB=sqlserver ./run.sh SQL Server in Docker instead (gives the Queries tab real SQL statements)
#   PORT=5000 ./run.sh       a fixed port;  HOST=127.0.0.1 ./run.sh  loopback only
#   ./run.sh traffic         sample traffic: failed and good logins, protected pages, orders, a bad form
#   ./run.sh stop-db         remove the SQL Server container
#
# Needs the .NET SDK 8 or later and internet access for the first build (NuGet, and cdnjs for the web libraries).
# Telemetry: OTEL_EXPORTER_OTLP_ENDPOINT (default http://127.0.0.1:4318), service eshop-web, environment test.
set -euo pipefail
cd "$(dirname "$0")"
ROOT=$PWD; STATE=$ROOT/.ow-run; mkdir -p "$STATE"
export OTEL_EXPORTER_OTLP_ENDPOINT="${OTEL_EXPORTER_OTLP_ENDPOINT:-http://127.0.0.1:4318}"
export OTEL_SERVICE_NAME="${OTEL_SERVICE_NAME:-eshop-web}" OW_ENVIRONMENT="${OW_ENVIRONMENT:-test}"
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1
free_port() { python3 -c "import socket;s=socket.socket();s.bind(('0.0.0.0',0));print(s.getsockname()[1]);s.close()" 2>/dev/null \
  || echo $(( 20000 + RANDOM % 40000 )); }

login() { # login <cookie-jar> <email> <password>
  local base=$1 jar=$2 tok
  tok=$(curl -s -c "$jar" -b "$jar" "$base/Identity/Account/Login" | grep -o 'name="__RequestVerificationToken" type="hidden" value="[^"]*"' | sed 's/.*value="//;s/"$//' | head -1)
  curl -s -o /dev/null -c "$jar" -b "$jar" --data-urlencode "Input.Email=$3" --data-urlencode "Input.Password=$4" \
    --data-urlencode "__RequestVerificationToken=$tok" "$base/Identity/Account/Login"
}

traffic() {
  local base="http://127.0.0.1:$(cat "$STATE/port")" c="curl -s -o /dev/null" jar="$STATE/jar"
  echo "== sending traffic to $base"
  for p in / "/?CatalogModel.BrandFilterApplied=2&CatalogModel.TypesFilterApplied=1" "/?pageId=1" /Basket /health "/?q=%27%20OR%201%3D1--"; do $c "$base$p"; done
  for p in /order/my-orders /Basket/Checkout /order/detail/1 /admin; do $c "$base$p"; done          # anonymous: login required
  for i in $(seq 1 10); do rm -f "$jar"; login "$base" "$jar" "user$i@example.com" "wrong-$i"; done
  rm -f "$jar"; login "$base" "$jar" "not-an-email" ""                                              # validation errors
  rm -f "$jar"; login "$base" "$jar" demouser@microsoft.com 'Pass@word1'
  for p in /order/my-orders /order/detail/1 /order/detail/99999 /Basket "/manage/my-account"; do $c -b "$jar" "$base$p"; done
  echo "done: check Application -> Services -> $OTEL_SERVICE_NAME in a minute"
}

start_sqlserver() {
  [ -f "$STATE/sa.pw" ] || echo "Ow-$(python3 -c 'import secrets;print(secrets.token_hex(8))')!" > "$STATE/sa.pw"
  local pw; pw=$(cat "$STATE/sa.pw")
  if ! docker ps --format '{{.Names}}' | grep -qx ow-eshop-sql; then
    docker rm -f ow-eshop-sql >/dev/null 2>&1 || true
    echo "== starting SQL Server in Docker (first pull is large)"
    docker run -d --name ow-eshop-sql -e ACCEPT_EULA=Y -e MSSQL_SA_PASSWORD="$pw" -p 127.0.0.1::1433 mcr.microsoft.com/mssql/server:2022-latest >/dev/null
    sleep 20
  fi
  local port; port=$(docker port ow-eshop-sql 1433/tcp | head -1 | sed 's/.*://')
  export UseOnlyInMemoryDatabase=false
  export ConnectionStrings__CatalogConnection="Server=127.0.0.1,$port;User Id=sa;Password=$pw;TrustServerCertificate=True;Initial Catalog=Microsoft.eShopOnWeb.CatalogDb;"
  export ConnectionStrings__IdentityConnection="Server=127.0.0.1,$port;User Id=sa;Password=$pw;TrustServerCertificate=True;Initial Catalog=Microsoft.eShopOnWeb.Identity;"
}

case "${1:-}" in
  traffic) traffic; exit 0 ;;
  stop-db) docker rm -f ow-eshop-sql; exit 0 ;;
esac
command -v dotnet >/dev/null || { echo "The .NET SDK 8 or later is required (https://dot.net)"; exit 1; }
DLL=src/Web/bin/Debug/net8.0/Web.dll
if [ ! -f "$DLL" ] || [ -n "$(find src -newer "$DLL" \( -name '*.cs' -o -name '*.csproj' -o -name '*.cshtml' -o -name '*.razor' \) 2>/dev/null | head -1)" ]; then
  echo "== building (first time: a few minutes, restores NuGet packages)"
  dotnet build src/Web/Web.csproj -c Debug -nologo -v q
fi
export ASPNETCORE_ENVIRONMENT=Development UseOnlyInMemoryDatabase="${UseOnlyInMemoryDatabase:-true}"
[ "${OW_DB:-}" = sqlserver ] && start_sqlserver
export DOTNET_ROLL_FORWARD=Major   # run the net8.0 app on a newer runtime when .NET 8 itself is not installed
PORT="${PORT:-$(free_port)}"; echo "$PORT" > "$STATE/port"
export ASPNETCORE_URLS="http://${HOST:-0.0.0.0}:$PORT" baseUrls__webBase="http://127.0.0.1:$PORT/"
echo "== eShopOnWeb on http://${HOST:-0.0.0.0}:$PORT, telemetry to $OTEL_EXPORTER_OTLP_ENDPOINT as $OTEL_SERVICE_NAME"
echo "   sign in as demouser@microsoft.com / Pass@word1;  send traffic from another terminal: ./run.sh traffic"
cd src/Web && exec dotnet bin/Debug/net8.0/Web.dll
