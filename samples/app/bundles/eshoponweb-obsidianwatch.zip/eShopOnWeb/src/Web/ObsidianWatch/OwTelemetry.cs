// ObsidianWatch instrumentation for eShopOnWeb (.NET, Tier 2): traces, runtime metrics and security-helper
// log records to the local agent only (OTEL_EXPORTER_OTLP_ENDPOINT, default http://127.0.0.1:4318).
// OW_TELEMETRY=0 turns it off.
using System.Diagnostics;
using System.Text.Json;
using OpenTelemetry.Exporter;
using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

namespace Microsoft.eShopWeb.Web.ObsidianWatch;

public static class OwTelemetry
{
    static bool Enabled => Environment.GetEnvironmentVariable("OW_TELEMETRY") != "0";

    static string Endpoint =>
        (Environment.GetEnvironmentVariable("OTEL_EXPORTER_OTLP_ENDPOINT") ?? "http://127.0.0.1:4318").TrimEnd('/');

    static string Commit()
    {
        var c = Environment.GetEnvironmentVariable("GIT_COMMIT");
        if (!string.IsNullOrEmpty(c)) return c;
        var f = Path.Combine(AppContext.BaseDirectory, "ObsidianWatch", "UPSTREAM_COMMIT");
        return File.Exists(f) ? File.ReadAllText(f).Trim() : "";
    }

    public static WebApplicationBuilder AddObsidianWatch(this WebApplicationBuilder builder)
    {
        builder.Services.AddSingleton<OwSecurity>();
        if (!Enabled) return builder;

        var name = Environment.GetEnvironmentVariable("OTEL_SERVICE_NAME") ?? "eshop-web";
        var resource = ResourceBuilder.CreateDefault()
            .AddService(name, serviceVersion: Environment.GetEnvironmentVariable("APP_VERSION") ?? "1.0.0")
            .AddAttributes(new KeyValuePair<string, object>[]
            {
                new("deployment.environment.name", Environment.GetEnvironmentVariable("OW_ENVIRONMENT") ?? "test"),
                new("vcs.repository.url.full", "https://github.com/dotnet-architecture/eShopOnWeb"),
                new("vcs.ref.head.revision", Commit()),
            });

        builder.Services.AddOpenTelemetry()
            .WithTracing(t => t
                .SetResourceBuilder(resource)
                .AddAspNetCoreInstrumentation(o =>
                {
                    o.RecordException = true;
                    o.EnrichWithHttpRequest = (activity, request) =>
                    {
                        var ip = request.HttpContext.Connection.RemoteIpAddress?.ToString();
                        if (ip != null)
                        {
                            activity.SetTag("client.address", ip);
                            activity.SetTag("network.peer.address", ip);
                        }
                    };
                })
                .AddHttpClientInstrumentation()
                .AddSqlClientInstrumentation(o => o.SetDbStatementForText = true)
                .AddOtlpExporter(o =>
                {
                    o.Endpoint = new Uri(Endpoint + "/v1/traces");
                    o.Protocol = OtlpExportProtocol.HttpProtobuf;
                }))
            .WithMetrics(m => m
                .SetResourceBuilder(resource)
                .AddRuntimeInstrumentation()
                .AddAspNetCoreInstrumentation()
                .AddOtlpExporter(o =>
                {
                    o.Endpoint = new Uri(Endpoint + "/v1/metrics");
                    o.Protocol = OtlpExportProtocol.HttpProtobuf;
                }));

        builder.Logging.AddOpenTelemetry(o =>
        {
            o.SetResourceBuilder(resource);
            o.IncludeFormattedMessage = false;
            o.ParseStateValues = true;
            o.IncludeScopes = false;
            o.AddOtlpExporter(x =>
            {
                x.Endpoint = new Uri(Endpoint + "/v1/logs");
                x.Protocol = OtlpExportProtocol.HttpProtobuf;
            });
        });
        Console.WriteLine($"[obsidianwatch] telemetry to {Endpoint} as {name}");
        return builder;
    }

    /// <summary>First middleware: form field names on the server span, 401/403 as authz.deny.</summary>
    public static WebApplication UseObsidianWatch(this WebApplication app)
    {
        if (!Enabled) return app;
        app.Use(async (context, next) =>
        {
            try
            {
                if (HttpMethods.IsPost(context.Request.Method) && context.Request.HasFormContentType
                    && Activity.Current is { } activity)
                {
                    var form = await context.Request.ReadFormAsync();
                    var body = JsonSerializer.Serialize(form.ToDictionary(kv => kv.Key, kv => kv.Value.ToString()));
                    if (body.Length > 2 && body.Length <= 32 * 1024) activity.SetTag("ow.request.body", body);
                }
            }
            catch (Exception)
            {
                // observability must never break a request
            }
            await next();
            var status = context.Response.StatusCode;
            if (status == 401 || status == 403)
            {
                Sec(context)?.AuthzDenied("page", context.Request.Method.ToLowerInvariant(), context.User.Identity?.Name,
                    Route(context), Client(context));
            }
        });
        return app;
    }

    public static OwSecurity? Sec(HttpContext context) => Enabled ? context.RequestServices.GetService<OwSecurity>() : null;

    public static string? Client(HttpContext context) => context.Connection.RemoteIpAddress?.ToString();

    /// <summary>The route template of the matched endpoint, or the path.</summary>
    public static string Route(HttpContext context) =>
        (context.GetEndpoint() as RouteEndpoint)?.RoutePattern.RawText is { } t ? "/" + t.TrimStart('/') : context.Request.Path.Value ?? "/";
}
