# eShopOnWeb, instrumented for ObsidianWatch (.NET, Tier 2)

Upstream: https://github.com/dotnet-architecture/eShopOnWeb at the commit in `src/Web/ObsidianWatch/UPSTREAM_COMMIT`
(ASP.NET Core 8 MVC + Razor Pages + Identity). Only the Web app is run; the Blazor admin needs the separate
PublicApi project, which this bundle does not start.

## Run
    ./run.sh                   # builds if needed, starts on a random free port on 0.0.0.0, in-memory database
    OW_DB=sqlserver ./run.sh   # SQL Server 2022 in Docker instead, so the Queries tab shows SQL (first pull ~1.5 GB)
    ./run.sh traffic           # second terminal: failed/good logins, protected pages, orders, a bad login form
    PORT=5000 ./run.sh         # fixed port;  HOST=127.0.0.1 ./run.sh to bind loopback only

Sign in as demouser@microsoft.com / Pass@word1. Needs the .NET SDK 8 or later (global.json now rolls forward
to newer majors; `DOTNET_ROLL_FORWARD=Major` lets the net8.0 app run on a newer runtime) and internet for the
first build (NuGet, cdnjs for libman). Telemetry: agent at `OTEL_EXPORTER_OTLP_ENDPOINT` (default
http://127.0.0.1:4318), service `eshop-web`, environment `test`. `OW_TELEMETRY=0` turns it off.

## What was changed (marked "ObsidianWatch")
- `Directory.Packages.props`, `src/Web/Web.csproj` — OpenTelemetry 1.9.0 (hosting, OTLP exporter, ASP.NET Core,
  HttpClient, runtime, SqlClient 1.9.0-beta.1).
- `src/Web/ObsidianWatch/OwTelemetry.cs` — resource (name, environment, version, repository, commit), tracing
  with `RecordException` and the client address, SqlClient statements, runtime + ASP.NET metrics, the logs
  provider with `ParseStateValues` for the helper, and the first middleware: form field names on the server
  span (`ow.request.body`) and 401/403 as authz.deny.
- `src/Web/ObsidianWatch/OwSecurity.cs` — the helper from samples/app/dotnet (namespace added).
- `Program.cs` — `builder.AddObsidianWatch()`, `app.UseObsidianWatch()`; auth cookie `SecurePolicy` is
  `SameAsRequest` instead of `Always` so sign-in works over plain HTTP on the random port.
- `Areas/Identity/Pages/Account/Login.cshtml.cs` — auth.login success/failure (invalid credentials, locked out,
  MFA required), input.rejected for invalid form fields.
- `Configuration/RevokeAuthenticationEvents.cs` — authz.deny for redirects to login / access denied (cookie
  authentication answers with 302, not 401/403).
- `Controllers/OrderController.cs` — data.export for My Orders, data.access for an order, authz.deny for an
  order that is not the user's.
- `global.json` — `rollForward: latestMajor`.
Note: failed logins re-render the page with 200, so APP-A01 (401/403 on login routes) does not fire; the
auth.login failure events fill the Security tab.

## What to look at (Applications -> Services -> eshop-web)
Tier 2; Endpoints (`/order/detail/{orderId}`, `/Identity/Account/Login` ...); Security (auth.login, authz.deny,
input.rejected, data.export, data.access); Queries (only with OW_DB=sqlserver); Metrics (dotnet runtime);
Instances (verified `dotnet`, the upstream commit).

## Test status
Not built or run where it was prepared: NuGet, Microsoft's registries and Docker Hub were unreachable there.
`OwTelemetry.cs`, `OwSecurity.cs` and `RevokeAuthenticationEvents.cs` were compiled with the .NET 8 SDK against
the real ASP.NET Core 8 framework and stand-ins for the OpenTelemetry 1.9 API. The login and order edits are
small calls into those classes. If the build reports an error, send the output.
