// ow-orders: a small order service on PostgreSQL, instrumented for ObsidianWatch (Go, Tier 2) the way
// docs/application/configuration-go.md describes: the OpenTelemetry Go SDK and otelhttp for the server span,
// route templates from http.ServeMux patterns, owpayload for request field names, owsecurity for the security
// events, otelsql for database spans, and the commit and repository as resource attributes.
package main

import (
	"context"
	"crypto/pbkdf2"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/XSAM/otelsql"
	_ "github.com/lib/pq"
	"go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/propagation"
	"go.opentelemetry.io/otel/sdk/resource"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/trace"

	"ow-orders/owpayload"
	"ow-orders/owsecurity"
)

// Set at build time by run.sh: -ldflags "-X main.commit=... -X main.version=...".
var (
	commit  = ""
	version = "1.0.0"
)

func envOr(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

// ---- telemetry ----

func setupTelemetry(ctx context.Context) func() {
	endpoint := strings.TrimRight(envOr("OTEL_EXPORTER_OTLP_ENDPOINT", "http://127.0.0.1:4318"), "/")
	attrs := map[string]string{
		"service.name":                envOr("OTEL_SERVICE_NAME", "ow-orders-go"),
		"deployment.environment.name": envOr("OW_ENVIRONMENT", "test"),
		"service.version":             version,
	}
	if repo := os.Getenv("OW_REPOSITORY"); repo != "" { // step 11: links the Code tab when the repository is connected
		attrs["vcs.repository.url.full"] = repo
	}
	if commit != "" {
		attrs["vcs.ref.head.revision"] = commit
	}
	kv := make([]attribute.KeyValue, 0, len(attrs))
	for k, v := range attrs {
		kv = append(kv, attribute.String(k, v))
	}
	exp, err := otlptracehttp.New(ctx, otlptracehttp.WithEndpointURL(endpoint+"/v1/traces"))
	if err != nil {
		log.Fatal(err)
	}
	res, _ := resource.New(ctx, resource.WithTelemetrySDK(), resource.WithAttributes(kv...))
	tp := sdktrace.NewTracerProvider(sdktrace.WithResource(res), sdktrace.WithBatcher(exp))
	otel.SetTracerProvider(tp)
	otel.SetTextMapPropagator(propagation.TraceContext{})
	stopSec := owsecurity.Init(endpoint+"/v1/logs", attrs)
	log.Printf("[obsidianwatch] telemetry to %s as %s", endpoint, attrs["service.name"])
	return func() {
		stopSec()
		sctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		_ = tp.Shutdown(sctx)
	}
}

// handle registers a route and names the server span after its template (configuration-go.md step 5).
func handle(mux *http.ServeMux, pattern string, fn http.HandlerFunc) {
	method, route, _ := strings.Cut(pattern, " ")
	mux.Handle(pattern, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		span := trace.SpanFromContext(r.Context())
		span.SetName(method + " " + route)
		span.SetAttributes(attribute.String("http.route", route))
		fn(w, r)
	}))
}

func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

// clientAddress records the client and peer address on the server span (step 6).
func clientAddress(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ip := clientIP(r)
		trace.SpanFromContext(r.Context()).SetAttributes(attribute.String("client.address", ip), attribute.String("network.peer.address", ip))
		next.ServeHTTP(w, r)
	})
}

// fail records an error on the server span (step 8) and answers 500.
func fail(w http.ResponseWriter, r *http.Request, err error) {
	span := trace.SpanFromContext(r.Context())
	span.RecordError(err, trace.WithStackTrace(true))
	span.SetStatus(codes.Error, err.Error())
	writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "internal error"})
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

// ---- data ----

type app struct {
	db       *sql.DB
	mu       sync.Mutex
	sessions map[string]user        // token -> user
	failures map[string][]time.Time // account -> recent failed logins
}

type user struct {
	ID    int64
	Email string
	Admin bool
}

const schema = `
CREATE TABLE IF NOT EXISTS users (id BIGSERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL, salt TEXT NOT NULL, hash TEXT NOT NULL, admin BOOLEAN NOT NULL DEFAULT false);
CREATE TABLE IF NOT EXISTS products (id BIGSERIAL PRIMARY KEY, name TEXT UNIQUE NOT NULL, price_cents INT NOT NULL);
CREATE TABLE IF NOT EXISTS orders (id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id), product_id BIGINT NOT NULL REFERENCES products(id), qty INT NOT NULL, note TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS audit (id BIGSERIAL PRIMARY KEY, actor BIGINT, action TEXT NOT NULL, target TEXT NOT NULL, at TIMESTAMPTZ NOT NULL DEFAULT now());`

func hashPassword(password, salt string) string {
	k, _ := pbkdf2.Key(sha256.New, password, []byte(salt), 100_000, 32)
	return hex.EncodeToString(k)
}

func (a *app) seed(ctx context.Context) error {
	if _, err := a.db.ExecContext(ctx, schema); err != nil {
		return err
	}
	pw := envOr("OW_DEMO_PASSWORD", "orders-demo-1")
	for _, u := range []struct {
		email string
		admin bool
	}{{"alice@example.com", false}, {"bob@example.com", false}, {"admin@example.com", true}} {
		salt := u.email
		if _, err := a.db.ExecContext(ctx, `INSERT INTO users (email, salt, hash, admin) VALUES ($1, $2, $3, $4) ON CONFLICT (email) DO NOTHING`,
			u.email, salt, hashPassword(pw, salt), u.admin); err != nil {
			return err
		}
	}
	for i, p := range []string{"keyboard", "mouse", "monitor", "laptop stand", "usb hub", "headset"} {
		if _, err := a.db.ExecContext(ctx, `INSERT INTO products (name, price_cents) VALUES ($1, $2) ON CONFLICT (name) DO NOTHING`, p, 1999+i*1500); err != nil {
			return err
		}
	}
	return nil
}

// ---- auth ----

func (a *app) current(r *http.Request) (user, bool) {
	tok := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	a.mu.Lock()
	defer a.mu.Unlock()
	u, ok := a.sessions[tok]
	return u, ok
}

// authed answers 401 (and reports authz.deny) without a valid session.
func (a *app) authed(route string, fn func(http.ResponseWriter, *http.Request, user)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		u, ok := a.current(r)
		if !ok {
			owsecurity.AuthzDenied(r.Context(), "api", strings.ToLower(r.Method), "", route, clientIP(r), "authenticated")
			writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "sign in first"})
			return
		}
		fn(w, r, u)
	}
}

// tooManyFailures is a 5-per-minute limit on failed sign-ins per account (password guessing on one user).
func (a *app) tooManyFailures(account string) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	cut := time.Now().Add(-time.Minute)
	var keep []time.Time
	for _, t := range a.failures[account] {
		if t.After(cut) {
			keep = append(keep, t)
		}
	}
	a.failures[account] = keep
	return len(keep) >= 5
}

func (a *app) failed(account string) {
	a.mu.Lock()
	a.failures[account] = append(a.failures[account], time.Now())
	a.mu.Unlock()
}

func (a *app) login(w http.ResponseWriter, r *http.Request) {
	const route = "/api/login"
	ip := clientIP(r)
	var b struct{ Email, Password string }
	if err := json.NewDecoder(r.Body).Decode(&b); err != nil || b.Email == "" {
		owsecurity.InputRejected(r.Context(), "validation", route, "email", ip)
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "email and password are required"})
		return
	}
	account := strings.ToLower(b.Email)
	if a.tooManyFailures(account) {
		owsecurity.RateLimited(r.Context(), "login", route, ip, b.Email)
		writeJSON(w, http.StatusTooManyRequests, map[string]string{"error": "too many attempts, wait a minute"})
		return
	}
	var u user
	var salt, hash string
	err := a.db.QueryRowContext(r.Context(), `SELECT id, email, admin, salt, hash FROM users WHERE email = $1`, account).
		Scan(&u.ID, &u.Email, &u.Admin, &salt, &hash)
	if errors.Is(err, sql.ErrNoRows) || (err == nil && subtle.ConstantTimeCompare([]byte(hashPassword(b.Password, salt)), []byte(hash)) != 1) {
		reason := "invalid_credentials"
		if errors.Is(err, sql.ErrNoRows) {
			reason = "unknown_user"
		}
		a.failed(account)
		owsecurity.Login(r.Context(), "failure", b.Email, ip, route, "password", reason)
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "invalid email or password"})
		return
	}
	if err != nil {
		fail(w, r, err)
		return
	}
	tok := make([]byte, 24)
	_, _ = rand.Read(tok)
	a.mu.Lock()
	a.sessions[hex.EncodeToString(tok)] = u
	a.mu.Unlock()
	owsecurity.Login(r.Context(), "success", u.Email, ip, route, "password", "")
	writeJSON(w, http.StatusOK, map[string]any{"token": hex.EncodeToString(tok), "admin": u.Admin})
}

// ---- handlers ----

type order struct {
	ID        int64     `json:"id"`
	UserID    int64     `json:"user_id"`
	Product   string    `json:"product"`
	Qty       int       `json:"qty"`
	Note      string    `json:"note"`
	CreatedAt time.Time `json:"created_at"`
}

func (a *app) products(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query().Get("q")
	rows, err := a.db.QueryContext(r.Context(), `SELECT id, name, price_cents FROM products WHERE name ILIKE '%' || $1 || '%' ORDER BY name`, q)
	if err != nil {
		fail(w, r, err)
		return
	}
	defer rows.Close()
	type product struct {
		ID    int64  `json:"id"`
		Name  string `json:"name"`
		Cents int    `json:"price_cents"`
	}
	out := []product{}
	for rows.Next() {
		var p product
		if err := rows.Scan(&p.ID, &p.Name, &p.Cents); err != nil {
			fail(w, r, err)
			return
		}
		out = append(out, p)
	}
	writeJSON(w, http.StatusOK, out)
}

func (a *app) listOrders(w http.ResponseWriter, r *http.Request, u user) {
	query := `SELECT o.id, o.user_id, p.name, o.qty, o.note, o.created_at FROM orders o JOIN products p ON p.id = o.product_id WHERE o.user_id = $1 ORDER BY o.id DESC LIMIT 200`
	args := []any{u.ID}
	if u.Admin && r.URL.Query().Get("all") == "1" {
		query = `SELECT o.id, o.user_id, p.name, o.qty, o.note, o.created_at FROM orders o JOIN products p ON p.id = o.product_id ORDER BY o.id DESC LIMIT 200`
		args = nil
	}
	rows, err := a.db.QueryContext(r.Context(), query, args...)
	if err != nil {
		fail(w, r, err)
		return
	}
	defer rows.Close()
	out := []order{}
	for rows.Next() {
		var o order
		if err := rows.Scan(&o.ID, &o.UserID, &o.Product, &o.Qty, &o.Note, &o.CreatedAt); err != nil {
			fail(w, r, err)
			return
		}
		out = append(out, o)
	}
	if r.URL.Query().Get("format") == "csv" {
		owsecurity.DataExport(r.Context(), "order", u.Email, "csv", len(out), "/api/orders", clientIP(r))
		w.Header().Set("Content-Type", "text/csv")
		fmt.Fprintln(w, "id,user_id,product,qty,created_at")
		for _, o := range out {
			fmt.Fprintf(w, "%d,%d,%q,%d,%s\n", o.ID, o.UserID, o.Product, o.Qty, o.CreatedAt.Format(time.RFC3339))
		}
		return
	}
	writeJSON(w, http.StatusOK, out)
}

func (a *app) createOrder(w http.ResponseWriter, r *http.Request, u user) {
	var b struct {
		ProductID int64  `json:"product_id"`
		Qty       int    `json:"qty"`
		Note      string `json:"note"`
	}
	if err := json.NewDecoder(r.Body).Decode(&b); err != nil || b.ProductID <= 0 || b.Qty <= 0 || b.Qty > 100 || len(b.Note) > 500 {
		field := "qty"
		if b.ProductID <= 0 {
			field = "product_id"
		}
		owsecurity.InputRejected(r.Context(), "validation", "/api/orders", field, clientIP(r))
		writeJSON(w, http.StatusUnprocessableEntity, map[string]string{"error": "product_id and qty (1-100) are required"})
		return
	}
	var id int64
	err := a.db.QueryRowContext(r.Context(), `INSERT INTO orders (user_id, product_id, qty, note) VALUES ($1, $2, $3, $4) RETURNING id`, u.ID, b.ProductID, b.Qty, b.Note).Scan(&id)
	if err != nil {
		if strings.Contains(err.Error(), "foreign key") {
			owsecurity.InputRejected(r.Context(), "validation", "/api/orders", "product_id", clientIP(r))
			writeJSON(w, http.StatusUnprocessableEntity, map[string]string{"error": "no such product"})
			return
		}
		fail(w, r, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]int64{"id": id})
}

func (a *app) getOrder(w http.ResponseWriter, r *http.Request, u user) {
	const route = "/api/orders/{id}"
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		owsecurity.InputRejected(r.Context(), "validation", route, "id", clientIP(r))
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "bad id"})
		return
	}
	var o order
	err = a.db.QueryRowContext(r.Context(), `SELECT o.id, o.user_id, p.name, o.qty, o.note, o.created_at FROM orders o JOIN products p ON p.id = o.product_id WHERE o.id = $1`, id).
		Scan(&o.ID, &o.UserID, &o.Product, &o.Qty, &o.Note, &o.CreatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		writeJSON(w, http.StatusNotFound, map[string]string{"error": "not found"})
		return
	}
	if err != nil {
		fail(w, r, err)
		return
	}
	if o.UserID != u.ID && !u.Admin {
		owsecurity.AuthzDenied(r.Context(), "order", "read", u.Email, route, clientIP(r), "owner_only")
		writeJSON(w, http.StatusForbidden, map[string]string{"error": "not your order"})
		return
	}
	owsecurity.DataAccess(r.Context(), "order", strconv.FormatInt(id, 10), u.Email, route, clientIP(r))
	writeJSON(w, http.StatusOK, o)
}

func (a *app) deleteOrder(w http.ResponseWriter, r *http.Request, u user) {
	const route = "/api/orders/{id}"
	if !u.Admin {
		owsecurity.AuthzDenied(r.Context(), "order", "delete", u.Email, route, clientIP(r), "admin_only")
		writeJSON(w, http.StatusForbidden, map[string]string{"error": "admins only"})
		return
	}
	id := r.PathValue("id")
	tx, err := a.db.BeginTx(r.Context(), nil)
	if err != nil {
		fail(w, r, err)
		return
	}
	defer tx.Rollback()
	res, err := tx.ExecContext(r.Context(), `DELETE FROM orders WHERE id = $1`, id)
	if err != nil {
		fail(w, r, err)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		writeJSON(w, http.StatusNotFound, map[string]string{"error": "not found"})
		return
	}
	if _, err := tx.ExecContext(r.Context(), `INSERT INTO audit (actor, action, target) VALUES ($1, 'order.delete', $2)`, u.ID, id); err != nil {
		fail(w, r, err)
		return
	}
	if err := tx.Commit(); err != nil {
		fail(w, r, err)
		return
	}
	owsecurity.AdminAction(r.Context(), "order.delete", u.Email, "order", id, clientIP(r))
	w.WriteHeader(http.StatusNoContent)
}

// report has a deliberate bug (a column that does not exist) so the Errors and Queries tabs show a failing query.
func (a *app) report(w http.ResponseWriter, r *http.Request, u user) {
	var n int
	if err := a.db.QueryRowContext(r.Context(), `SELECT count(*) FROM orders WHERE shipped_at IS NULL AND user_id = $1`, u.ID).Scan(&n); err != nil {
		fail(w, r, fmt.Errorf("unshipped report: %w", err))
		return
	}
	writeJSON(w, http.StatusOK, map[string]int{"unshipped": n})
}

func main() {
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	stop := setupTelemetry(ctx)
	defer stop()

	dsn := envOr("DATABASE_URL", "postgres://postgres@127.0.0.1:5432/orders?sslmode=disable")
	// Step 10: open the database through otelsql, so every query is a client span with the statement.
	// The span options drop otelsql's connection and row-iteration spans, which carry no statement.
	db, err := otelsql.Open("postgres", dsn, otelsql.WithAttributes(attribute.String("db.system", "postgresql")),
		otelsql.WithSpanOptions(otelsql.SpanOptions{OmitConnResetSession: true, OmitConnectorConnect: true, OmitRows: true}))
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	a := &app{db: db, sessions: map[string]user{}, failures: map[string][]time.Time{}}
	for i := 0; ; i++ {
		if err = a.seed(ctx); err == nil {
			break
		}
		if i == 10 {
			log.Fatal("database: ", err)
		}
		time.Sleep(time.Second)
	}

	mux := http.NewServeMux()
	handle(mux, "GET /api/health", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, 200, map[string]string{"status": "ok"}) })
	handle(mux, "POST /api/login", a.login)
	handle(mux, "GET /api/products", a.products)
	handle(mux, "GET /api/orders", a.authed("/api/orders", a.listOrders))
	handle(mux, "POST /api/orders", a.authed("/api/orders", a.createOrder))
	handle(mux, "GET /api/orders/{id}", a.authed("/api/orders/{id}", a.getOrder))
	handle(mux, "DELETE /api/orders/{id}", a.authed("/api/orders/{id}", a.deleteOrder))
	handle(mux, "GET /api/reports/unshipped", a.authed("/api/reports/unshipped", a.report))
	handle(mux, "GET /", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain")
		fmt.Fprintln(w, "ow-orders: GET /api/products?q=, POST /api/login {email,password}, GET|POST /api/orders, GET|DELETE /api/orders/{id}, GET /api/reports/unshipped")
	})

	// Step 4: owpayload inside otelhttp; the sign-in body (password) is never reported.
	h := otelhttp.NewHandler(owpayload.Middleware("/api/login")(clientAddress(mux)), "http.server")
	srv := &http.Server{Addr: envOr("HOST", "0.0.0.0") + ":" + envOr("PORT", "8080"), Handler: h, ReadHeaderTimeout: 10 * time.Second}
	go func() {
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatal(err)
		}
	}()
	log.Printf("listening on %s", srv.Addr)
	<-ctx.Done()
	sctx, scancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer scancel()
	_ = srv.Shutdown(sctx)
}
