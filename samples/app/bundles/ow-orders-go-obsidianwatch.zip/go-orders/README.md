# ow-orders: a Go service instrumented for ObsidianWatch (Tier 2, PostgreSQL through otelsql)

A small order API (sign-in, products, orders, an admin delete, a CSV export and a deliberately failing report)
built exactly the way docs/application/configuration-go.md describes:

| Doc step | Where |
|---|---|
| 3 tracer provider + security helper, same resource | `setupTelemetry` in main.go (OpenTelemetry Go v1.46.0) |
| 4 otelhttp outside, owpayload inside; sign-in body never reported | end of `main` |
| 5 span name and `http.route` from the ServeMux pattern | `handle` |
| 6 client address on the server span | `clientAddress` |
| 7 security events | `login` (auth.login, ratelimit.hit, input.rejected), `authed` and `getOrder`/`deleteOrder` (authz.deny), `deleteOrder` (admin.action), `listOrders` (data.export), `getOrder` (data.access), `createOrder` (input.rejected) |
| 8 errors on the span with stack | `fail` |
| 10 database through otelsql v0.44.0 | `otelsql.Open` in `main`, with the lifecycle spans omitted |
| 11 commit and repository | `-X main.commit` from `COMMIT` (or `git rev-parse HEAD`); `OW_REPOSITORY=<url>` sets the repository |

## Run
    ./run.sh               # builds (offline: vendor/ has every module), starts Postgres, serves on a random port on 0.0.0.0
    ./run.sh traffic       # second terminal
    ./run.sh stop-db
    PORT=8080 ./run.sh;  HOST=127.0.0.1 ./run.sh

Needs Go 1.25+ and Postgres: `DATABASE_URL` if you set it, else a `postgres:17` Docker container on a random
loopback port, else a local cluster with initdb (as root it runs as the `postgres` user). Users
alice@example.com, bob@example.com (users) and admin@example.com (admin), password `orders-demo-1`
(`OW_DEMO_PASSWORD`). Telemetry: `OTEL_EXPORTER_OTLP_ENDPOINT` (default http://127.0.0.1:4318), service
`ow-orders-go`, environment `test`.

## What to look at (Applications -> Services -> ow-orders-go)
Tier 2; Endpoints (`/api/orders/{id}` ...); Queries (SELECT/INSERT/DELETE per table with fingerprinted
statements, and the failing `select count(*) from orders where shipped_at is null ...`); Errors (the report's
`pq: column "shipped_at" does not exist`); Security (all of the events above); Instances (verified, sdk
opentelemetry 1.46.0, the commit).
