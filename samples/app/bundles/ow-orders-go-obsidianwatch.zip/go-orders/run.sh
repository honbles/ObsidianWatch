#!/usr/bin/env bash
# Run ow-orders (Go, Tier 2, PostgreSQL through otelsql) instrumented for ObsidianWatch.
#
#   ./run.sh            build if needed (offline: every dependency is in vendor/), start Postgres, start on a random port on 0.0.0.0
#   PORT=8080 ./run.sh  a fixed port;  HOST=127.0.0.1 ./run.sh  loopback only
#   ./run.sh traffic    sample traffic: failed logins (one account up to its rate limit), orders, someone else's order, admin delete, a failing report
#   ./run.sh stop-db    stop the Postgres this script started
#
# Needs Go 1.25+ (go.mod asks for 1.25.7; an older go downloads it) and Postgres: DATABASE_URL if set, else a
# postgres:17 Docker container, else a local cluster with initdb. Telemetry: OTEL_EXPORTER_OTLP_ENDPOINT
# (default http://127.0.0.1:4318). Users alice@example.com, bob@example.com, admin@example.com, password orders-demo-1.
set -euo pipefail
cd "$(dirname "$0")"
ROOT=$PWD; STATE=$ROOT/.ow-run; mkdir -p "$STATE"
export OTEL_EXPORTER_OTLP_ENDPOINT="${OTEL_EXPORTER_OTLP_ENDPOINT:-http://127.0.0.1:4318}"
export OTEL_SERVICE_NAME="${OTEL_SERVICE_NAME:-ow-orders-go}" OW_ENVIRONMENT="${OW_ENVIRONMENT:-test}"
PW="${OW_DEMO_PASSWORD:-orders-demo-1}"
free_port() { python3 -c "import socket;s=socket.socket();s.bind(('0.0.0.0',0));print(s.getsockname()[1]);s.close()" 2>/dev/null \
  || echo $(( 20000 + RANDOM % 40000 )); }

start_db() {
  if [ -n "${DATABASE_URL:-}" ]; then return; fi
  [ -f "$STATE/db.pw" ] || python3 -c "import secrets;print(secrets.token_hex(12))" > "$STATE/db.pw"
  local pw; pw=$(cat "$STATE/db.pw")
  if command -v docker >/dev/null && docker info >/dev/null 2>&1; then
    if ! docker ps --format '{{.Names}}' | grep -qx ow-orders-go-db; then
      docker rm -f ow-orders-go-db >/dev/null 2>&1 || true
      echo "== starting Postgres in Docker"
      docker run -d --name ow-orders-go-db -e POSTGRES_PASSWORD="$pw" -e POSTGRES_DB=orders -p 127.0.0.1::5432 postgres:17 >/dev/null \
        || echo "   Docker could not start postgres:17; trying a local PostgreSQL instead"
    fi
    if docker ps --format '{{.Names}}' | grep -qx ow-orders-go-db; then
      local dbport; dbport=$(docker port ow-orders-go-db 5432/tcp | head -1 | sed 's/.*://')
      for i in $(seq 1 30); do docker exec ow-orders-go-db pg_isready -U postgres -d orders >/dev/null 2>&1 && break; sleep 1; done
      sleep 1
      export DATABASE_URL="postgresql://postgres:$pw@127.0.0.1:$dbport/orders?sslmode=disable"; echo docker > "$STATE/db.kind"; return
    fi
  fi
  local bin="${PGBIN:-}"; [ -z "$bin" ] && command -v initdb >/dev/null && bin=$(dirname "$(command -v initdb)")
  [ -z "$bin" ] && bin=$(ls -d /usr/lib/postgresql/*/bin 2>/dev/null | sort -V | tail -1 || true)
  [ -n "$bin" ] && [ -x "$bin/initdb" ] || { echo "No Postgres: set DATABASE_URL, start Docker, or install PostgreSQL (initdb)"; exit 1; }
  # As root the cluster runs as "postgres", which may not enter this folder (/root is private): keep it in /var/lib.
  local pgh=$STATE; if [ "$(id -u)" = 0 ]; then pgh=/var/lib/ow-pg/$(basename "$ROOT"); mkdir -p "$pgh"; fi
  local data=$pgh/pgdata sock=$pgh/pgsock
  # initdb and postgres refuse to run as root: as root, run them as the "postgres" system user
  as_pg() { if [ "$(id -u)" = 0 ]; then su postgres -s /bin/sh -c "$*"; else sh -c "$*"; fi; }
  if [ "$(id -u)" = 0 ] && ! id postgres >/dev/null 2>&1; then echo "Running as root needs a 'postgres' system user for the local database (or set DATABASE_URL)"; exit 1; fi
  if [ ! -d "$data" ]; then
    echo "== creating a local Postgres cluster in .ow-run/pgdata"
    mkdir -p "$data" "$sock"; printf '%s\n' "$pw" > "$pgh/pw.tmp"
    [ "$(id -u)" = 0 ] && chown postgres "$pgh" "$data" "$sock" "$pgh/pw.tmp" && chmod 700 "$data"
    as_pg "'$bin/initdb' -D '$data' -U postgres --pwfile='$pgh/pw.tmp' -A scram-sha-256 >/dev/null"; rm -f "$pgh/pw.tmp"
  fi
  [ -f "$STATE/db.port" ] || free_port > "$STATE/db.port"
  local dbport; dbport=$(cat "$STATE/db.port")
  [ "$(id -u)" = 0 ] && touch "$pgh/pg.log" && chown postgres "$pgh/pg.log"
  as_pg "'$bin/pg_ctl' -D '$data' status" >/dev/null 2>&1 || as_pg "'$bin/pg_ctl' -D '$data' -l '$pgh/pg.log' -o '-p $dbport -k $sock -c listen_addresses=127.0.0.1' -w start" >/dev/null
  PGPASSWORD=$pw "$bin/psql" -h 127.0.0.1 -p "$dbport" -U postgres -tAc "select 1 from pg_database where datname='orders'" postgres | grep -q 1 \
    || PGPASSWORD=$pw "$bin/createdb" -h 127.0.0.1 -p "$dbport" -U postgres orders
  export DATABASE_URL="postgresql://postgres:$pw@127.0.0.1:$dbport/orders?sslmode=disable"; echo "local $bin $data" > "$STATE/db.kind"
}

stop_db() {
  case "$(cat "$STATE/db.kind" 2>/dev/null)" in
    docker) docker rm -f ow-orders-go-db ;;
    local*) b="$(cut -d' ' -f2 "$STATE/db.kind")"; d="$(cut -d' ' -f3 "$STATE/db.kind")"; d=${d:-$STATE/pgdata}
            if [ "$(id -u)" = 0 ]; then su postgres -s /bin/sh -c "'$b/pg_ctl' -D '$d' stop"; else "$b/pg_ctl" -D "$d" stop; fi ;;
  esac
}

stop_db() {
  case "$(cat "$STATE/db.kind" 2>/dev/null)" in
    docker) docker rm -f ow-orders-go-db ;;
    local*) b="$(cut -d' ' -f2 "$STATE/db.kind")"; d="$(cut -d' ' -f3 "$STATE/db.kind")"; d=${d:-$STATE/pgdata}
            if [ "$(id -u)" = 0 ]; then su postgres -s /bin/sh -c "'$b/pg_ctl' -D '$d' stop"; else "$b/pg_ctl" -D "$d" stop; fi ;;
  esac
}

token() { curl -s -H 'Content-Type: application/json' -d "{\"email\":\"$2\",\"password\":\"$3\"}" "$1/api/login" | python3 -c "import sys,json;print(json.load(sys.stdin).get('token',''))" 2>/dev/null || true; }

traffic() {
  local base="http://127.0.0.1:$(cat "$STATE/port")" c="curl -s -o /dev/null" ta tb tadm id
  echo "== sending traffic to $base"
  for q in "" key "mon" "%27%20OR%201%3D1--" "%3Cscript%3E"; do $c "$base/api/products?q=$q"; done
  for i in $(seq 1 4); do $c -H 'Content-Type: application/json' -d "{\"email\":\"user$i@example.com\",\"password\":\"guess$i\"}" "$base/api/login"; done        # unknown users
  for i in $(seq 1 7); do $c -H 'Content-Type: application/json' -d "{\"email\":\"victim@example.com\",\"password\":\"guess$i\"}" "$base/api/login"; done  # 5 failures, then 429
  $c -H 'Content-Type: application/json' -d '{"email":"","password":""}' "$base/api/login"
  $c "$base/api/orders"; $c -H "Authorization: Bearer nope" "$base/api/orders/1"                                                   # 401
  ta=$(token "$base" alice@example.com "$PW"); tb=$(token "$base" bob@example.com "$PW"); tadm=$(token "$base" admin@example.com "$PW")
  for p in 1 2 3; do $c -H "Authorization: Bearer $ta" -H 'Content-Type: application/json' -d "{\"product_id\":$p,\"qty\":$p,\"note\":\"from run.sh\"}" "$base/api/orders"; done
  $c -H "Authorization: Bearer $ta" -H 'Content-Type: application/json' -d '{"product_id":0,"qty":500}' "$base/api/orders"          # invalid
  $c -H "Authorization: Bearer $ta" -H 'Content-Type: application/json' -d '{"product_id":9999,"qty":1}' "$base/api/orders"         # no such product
  id=$(curl -s -H "Authorization: Bearer $ta" "$base/api/orders" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d[0]['id'] if d else '')" 2>/dev/null || true)
  if [ -n "$id" ]; then
    $c -H "Authorization: Bearer $ta" "$base/api/orders/$id"; $c -H "Authorization: Bearer $tb" "$base/api/orders/$id"            # owner ok, bob 403
    $c -X DELETE -H "Authorization: Bearer $tb" "$base/api/orders/$id"; $c -X DELETE -H "Authorization: Bearer $tadm" "$base/api/orders/$id"   # 403, admin ok
  fi
  $c -H "Authorization: Bearer $ta" "$base/api/orders/abc"
  $c -H "Authorization: Bearer $ta" "$base/api/orders?format=csv"; $c -H "Authorization: Bearer $tadm" "$base/api/orders?all=1&format=csv"
  for i in 1 2 3; do $c -H "Authorization: Bearer $ta" "$base/api/reports/unshipped"; done                                         # 500: failing query
  $c "$base/api/health"
  echo "done: check Application -> Services -> $OTEL_SERVICE_NAME in a minute"
}

case "${1:-}" in
  traffic) traffic; exit 0 ;;
  stop-db) stop_db; exit 0 ;;
esac
command -v go >/dev/null || { echo "Go 1.25 or later is required (https://go.dev/dl)"; exit 1; }
COMMIT=$(git rev-parse HEAD 2>/dev/null || cat COMMIT 2>/dev/null || true)
if [ ! -x bin/ow-orders ] || [ -n "$(find . -name '*.go' -newer bin/ow-orders -not -path './vendor/*' | head -1)" ]; then
  echo "== building"
  mkdir -p bin && GOFLAGS=-mod=vendor go build -trimpath -ldflags "-X main.commit=$COMMIT -X main.version=1.0.0" -o bin/ow-orders .
fi
start_db
PORT="${PORT:-$(free_port)}"; echo "$PORT" > "$STATE/port"
echo "== ow-orders on http://${HOST:-0.0.0.0}:$PORT, telemetry to $OTEL_EXPORTER_OTLP_ENDPOINT as $OTEL_SERVICE_NAME"
echo "   users alice@ / bob@ / admin@example.com, password $PW;  send traffic from another terminal: ./run.sh traffic"
export PORT DATABASE_URL OW_DEMO_PASSWORD="$PW"
exec bin/ow-orders
