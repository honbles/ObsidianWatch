#!/usr/bin/env bash
# Run the Full Stack FastAPI Template instrumented for ObsidianWatch (Python, Tier 2).
#
#   ./run.sh            install what is missing, start Postgres, migrate, start on a random free port on 0.0.0.0
#   PORT=8000 ./run.sh  a fixed port;  HOST=127.0.0.1 ./run.sh  loopback only
#   ./run.sh traffic    send sample traffic to the running app (logins, denied calls, bad input, admin actions)
#   ./run.sh stop-db    stop the Postgres this script started
#
# Postgres: DATABASE_URL if set; otherwise a Docker container (postgres:17) on a random loopback port; otherwise
# a local cluster with initdb/pg_ctl (set PGBIN if they are not on PATH). Needs uv (installed if missing), which
# fetches Python 3.14. Telemetry goes to the agent at OTEL_EXPORTER_OTLP_ENDPOINT (default http://127.0.0.1:4318).
set -euo pipefail
cd "$(dirname "$0")"
ROOT=$PWD; STATE=$ROOT/.ow-run; mkdir -p "$STATE"
export OTEL_EXPORTER_OTLP_ENDPOINT="${OTEL_EXPORTER_OTLP_ENDPOINT:-http://127.0.0.1:4318}"
export OTEL_SERVICE_NAME="${OTEL_SERVICE_NAME:-fastapi-template}"
export OW_ENVIRONMENT="${OW_ENVIRONMENT:-test}"
ADMIN=admin@example.com; ADMIN_PW="${FIRST_SUPERUSER_PASSWORD:-changethis}"
free_port() { python3 -c "import socket;s=socket.socket();s.bind(('0.0.0.0',0));print(s.getsockname()[1]);s.close()"; }

need_uv() {
  command -v uv >/dev/null && return
  [ -x "$HOME/.local/bin/uv" ] && { export PATH="$HOME/.local/bin:$PATH"; return; }
  echo "== installing uv"; python3 -m pip install --user --quiet uv 2>/dev/null || python3 -m pip install --user --quiet --break-system-packages uv
  export PATH="$HOME/.local/bin:$PATH"
}

start_db() {
  if [ -n "${DATABASE_URL:-}" ]; then return; fi
  [ -f "$STATE/db.pw" ] || python3 -c "import secrets;print(secrets.token_hex(12))" > "$STATE/db.pw"
  local pw; pw=$(cat "$STATE/db.pw")
  if command -v docker >/dev/null && docker info >/dev/null 2>&1; then
    if ! docker ps --format '{{.Names}}' | grep -qx ow-fastapi-template-db; then
      docker rm -f ow-fastapi-template-db >/dev/null 2>&1 || true
      echo "== starting Postgres in Docker"
      docker run -d --name ow-fastapi-template-db -e POSTGRES_PASSWORD="$pw" -e POSTGRES_DB=app -p 127.0.0.1::5432 postgres:17 >/dev/null \
        || echo "   Docker could not start postgres:17; trying a local PostgreSQL instead"
    fi
    if docker ps --format '{{.Names}}' | grep -qx ow-fastapi-template-db; then
      local dbport; dbport=$(docker port ow-fastapi-template-db 5432/tcp | head -1 | sed 's/.*://')
      for i in $(seq 1 30); do docker exec ow-fastapi-template-db pg_isready -U postgres -d app >/dev/null 2>&1 && break; sleep 1; done
      sleep 1
      export DATABASE_URL="postgresql://postgres:$pw@127.0.0.1:$dbport/app"; echo docker > "$STATE/db.kind"; return
    fi
  fi
  local bin="${PGBIN:-}"; [ -z "$bin" ] && command -v initdb >/dev/null && bin=$(dirname "$(command -v initdb)")
  [ -z "$bin" ] && bin=$(ls -d /usr/lib/postgresql/*/bin 2>/dev/null | sort -V | tail -1 || true)
  [ -n "$bin" ] && [ -x "$bin/initdb" ] || { echo "No Postgres: set DATABASE_URL, start Docker, or install PostgreSQL (initdb)"; exit 1; }
  # As root the cluster runs as "postgres", which may not enter this folder (/root is private): keep it in /var/lib.
  local pgh=$STATE; if [ "$(id -u)" = 0 ]; then pgh=/var/lib/ow-pg/$(basename "$ROOT"); mkdir -p "$pgh"; fi
  local data=$pgh/pgdata sock=$pgh/pgsock
  # initdb and postgres refuse to run as root: as root, run them as the "postgres" system user
  as_pg() { if [ "$(id -u)" = 0 ]; then su postgres -s /bin/sh -c "$*"; else sh -c "$*"; fi; }
  if [ "$(id -u)" = 0 ] && ! id postgres >/dev/null 2>&1; then echo "Running as root needs a 'postgres' system user for the local database (or set DATABASE_URL)"; exit 1; fi
  if [ ! -d "$data" ]; then
    echo "== creating a local Postgres cluster in .ow-run/pgdata"
    mkdir -p "$data" "$sock"; printf '%s\n' "$pw" > "$pgh/pw.tmp"
    [ "$(id -u)" = 0 ] && chown postgres "$pgh" "$data" "$sock" "$pgh/pw.tmp" && chmod 700 "$data"
    as_pg "'$bin/initdb' -D '$data' -U postgres --pwfile='$pgh/pw.tmp' -A scram-sha-256 >/dev/null"; rm -f "$pgh/pw.tmp"
  fi
  [ -f "$STATE/db.port" ] || free_port > "$STATE/db.port"
  local dbport; dbport=$(cat "$STATE/db.port")
  [ "$(id -u)" = 0 ] && touch "$pgh/pg.log" && chown postgres "$pgh/pg.log"
  as_pg "'$bin/pg_ctl' -D '$data' status" >/dev/null 2>&1 || as_pg "'$bin/pg_ctl' -D '$data' -l '$pgh/pg.log' -o '-p $dbport -k $sock -c listen_addresses=127.0.0.1' -w start" >/dev/null
  PGPASSWORD=$pw "$bin/psql" -h 127.0.0.1 -p "$dbport" -U postgres -tAc "select 1 from pg_database where datname='app'" postgres | grep -q 1 \
    || PGPASSWORD=$pw "$bin/createdb" -h 127.0.0.1 -p "$dbport" -U postgres app
  export DATABASE_URL="postgresql://postgres:$pw@127.0.0.1:$dbport/app"; echo "local $bin $data" > "$STATE/db.kind"
}

stop_db() {
  case "$(cat "$STATE/db.kind" 2>/dev/null)" in
    docker) docker rm -f ow-fastapi-template-db ;;
    local*) b="$(cut -d' ' -f2 "$STATE/db.kind")"; d="$(cut -d' ' -f3 "$STATE/db.kind")"; d=${d:-$STATE/pgdata}
            if [ "$(id -u)" = 0 ]; then su postgres -s /bin/sh -c "'$b/pg_ctl' -D '$d' stop"; else "$b/pg_ctl" -D "$d" stop; fi ;;
  esac
}

traffic() {
  local base="http://127.0.0.1:$(cat "$STATE/port")/api/v1" tok
  echo "== sending traffic to $base"
  for i in $(seq 1 12); do curl -s -o /dev/null -d "username=user$i@example.com&password=wrong$i" "$base/login/access-token"; done
  curl -s -o /dev/null -d "username=' OR 1=1 --&password=x" "$base/login/access-token"
  tok=$(curl -s -d "username=$ADMIN&password=$ADMIN_PW" "$base/login/access-token" | python3 -c "import sys,json;print(json.load(sys.stdin).get('access_token',''))")
  for u in /users/ /items/ /users/me; do curl -s -o /dev/null -H "Authorization: Bearer invalid" "$base$u"; done
  curl -s -o /dev/null -H 'Content-Type: application/json' -d '{"email":"not-an-email","password":"short"}' "$base/users/signup"
  curl -s -o /dev/null "$base/items/?limit=abc" -H "Authorization: Bearer $tok"
  local em="eval$RANDOM@example.com" utok uid
  curl -s -o /dev/null -H 'Content-Type: application/json' -d "{\"email\":\"$em\",\"password\":\"evaluation-pass-1\",\"full_name\":\"Eval User\"}" "$base/users/signup"
  utok=$(curl -s -d "username=$em&password=evaluation-pass-1" "$base/login/access-token" | python3 -c "import sys,json;print(json.load(sys.stdin).get('access_token',''))")
  for i in 1 2 3; do curl -s -o /dev/null -H "Authorization: Bearer $utok" -H 'Content-Type: application/json' -d "{\"title\":\"item $i\",\"description\":\"from run.sh\"}" "$base/items/"; done
  curl -s -o /dev/null -H "Authorization: Bearer $utok" "$base/items/"
  curl -s -o /dev/null -H "Authorization: Bearer $utok" "$base/users/"                       # 403: not a superuser
  curl -s -o /dev/null -H "Authorization: Bearer $tok" "$base/users/"                        # data.export
  uid=$(curl -s -H "Authorization: Bearer $tok" -H 'Content-Type: application/json' -d "{\"email\":\"admin-made$RANDOM@example.com\",\"password\":\"evaluation-pass-2\"}" "$base/users/" | python3 -c "import sys,json;print(json.load(sys.stdin).get('id',''))")
  [ -n "$uid" ] && curl -s -o /dev/null -X PATCH -H "Authorization: Bearer $tok" -H 'Content-Type: application/json' -d '{"full_name":"Renamed"}' "$base/users/$uid" \
    && curl -s -o /dev/null -X DELETE -H "Authorization: Bearer $tok" "$base/users/$uid"
  curl -s -o /dev/null "$base/utils/health-check/"
  echo "done: check Application -> Services -> $OTEL_SERVICE_NAME in a minute"
}

case "${1:-}" in
  traffic) traffic; exit 0 ;;
  stop-db) stop_db; exit 0 ;;
esac
need_uv
[ -x .venv/bin/fastapi ] && .venv/bin/python -c "import opentelemetry.instrumentation.fastapi" 2>/dev/null \
  || { echo "== installing Python dependencies"; uv sync --python 3.14 --no-dev; }
if [ ! -f backend/app/frontend/index.html ]; then
  echo "== building the web UI"; command -v bun >/dev/null || npm i -g bun
  bun install && (cd frontend && VITE_API_URL= bun run build)
fi
start_db
[ -f "$STATE/secret" ] || python3 -c "import secrets;print(secrets.token_urlsafe(32))" > "$STATE/secret"
export SECRET_KEY=$(cat "$STATE/secret") FIRST_SUPERUSER=$ADMIN FIRST_SUPERUSER_PASSWORD=$ADMIN_PW FASTAPI_ENV=development
echo "== migrating the database"
(cd backend && ../.venv/bin/alembic upgrade head >/dev/null && OW_TELEMETRY=0 ../.venv/bin/python app/initial_data.py >/dev/null 2>&1)
PORT="${PORT:-$(free_port)}"; echo "$PORT" > "$STATE/port"
echo "== FastAPI template on http://${HOST:-0.0.0.0}:$PORT  (UI /, API docs /docs), telemetry to $OTEL_EXPORTER_OTLP_ENDPOINT"
echo "   sign in as $ADMIN / $ADMIN_PW;  send traffic from another terminal: ./run.sh traffic"
cd backend && exec ../.venv/bin/fastapi run app/main.py --host "${HOST:-0.0.0.0}" --port "$PORT"
