# Full Stack FastAPI Template, instrumented for ObsidianWatch (Python, Tier 2)

Upstream: https://github.com/fastapi/full-stack-fastapi-template at the commit in `backend/app/ow/UPSTREAM_COMMIT`.

## Run
    ./run.sh               # installs what is missing, starts Postgres, migrates, serves UI + API on a random port on 0.0.0.0
    ./run.sh traffic       # second terminal: failed logins, denied calls, bad input, signup, items, admin user actions
    ./run.sh stop-db       # stop the Postgres the script started
    PORT=8000 ./run.sh     # fixed port;  HOST=127.0.0.1 ./run.sh to bind loopback only

Sign in to the UI as admin@example.com / changethis. Needs: python3 and curl; uv is installed if missing and
fetches Python 3.14. Postgres: `DATABASE_URL` if you set it, else a `postgres:17` Docker container on a random
loopback port, else a local cluster with initdb (PostgreSQL server package; as root it runs as the `postgres`
user). The web UI is prebuilt in `backend/app/frontend` (rebuilt with bun only if missing).
Telemetry: agent at `OTEL_EXPORTER_OTLP_ENDPOINT` (default http://127.0.0.1:4318), service `fastapi-template`,
environment `test` (OTEL_SERVICE_NAME, OW_ENVIRONMENT). `OW_TELEMETRY=0` runs it without instrumentation.

## What was changed (marked "ObsidianWatch")
- `backend/app/ow/telemetry.py` — tracer provider and resource (name, environment, version, repository, commit),
  FastAPI + SQLAlchemy + httpx instrumentation, a router dependency that records the client address and request
  body field names, and exception handlers: 401/403 -> authz.deny, validation errors -> input.rejected.
- `backend/app/ow/ow_security.py`, `ow_payload.py` — the helpers from samples/app/python, unchanged.
- `backend/app/main.py` — `telemetry.setup()`, the dependency on the API router, `telemetry.instrument(app, engine)`.
- `api/routes/login.py` — auth.login success/failure. `api/routes/users.py` — admin.action for user
  create/update/delete by a superuser, data.export for the user list.
- `backend/pyproject.toml` — OpenTelemetry dependencies. `.env` — SMTP off (no mail server).

Note: the template answers a failed login with 400, not 401, so APP-A01 (which counts 401/403 on login routes)
does not fire from it; the auth.login failure events still fill the Security tab.

## What to look at (Applications -> Services -> fastapi-template)
Tier 2; Endpoints (`/api/v1/users/{user_id}` ...); Queries (fingerprinted PostgreSQL statements, SELECT/INSERT/
UPDATE/DELETE per table; statements show from the agent's first settings pull, within 5 minutes of the
service appearing); Security; Instances (verified, version 0.1.0, the upstream commit); Events (`app:fastapi-template`).
