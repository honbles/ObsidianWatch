from pathlib import Path

import sentry_sdk
from fastapi import Depends, FastAPI
from fastapi.routing import APIRoute
from starlette.middleware.cors import CORSMiddleware

from app.api.main import api_router
from app.core.config import settings
from app.core.db import engine
from app.ow import telemetry  # ObsidianWatch

FRONTEND_DIR = Path(__file__).parent / "frontend"


def custom_generate_unique_id(route: APIRoute) -> str:
    return f"{route.tags[0]}-{route.name}"


if settings.SENTRY_DSN and settings.FASTAPI_ENV != "development":
    sentry_sdk.init(dsn=str(settings.SENTRY_DSN), enable_tracing=True)

telemetry.setup()  # ObsidianWatch: tracing and the security helper, before the app exists

app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    generate_unique_id_function=custom_generate_unique_id,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_HOST],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix=settings.API_V1_STR, dependencies=[Depends(telemetry.capture)])  # ObsidianWatch: client address, body fields
telemetry.instrument(app, engine)  # ObsidianWatch: FastAPI, SQLAlchemy, httpx; authz.deny and input.rejected
app.frontend("/", directory=FRONTEND_DIR)
