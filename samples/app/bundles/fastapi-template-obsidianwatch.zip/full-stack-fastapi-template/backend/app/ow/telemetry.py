"""ObsidianWatch instrumentation for the Full Stack FastAPI Template (Python, Tier 2).

setup() configures tracing and the security helper before the app is created; instrument(app, engine)
attaches FastAPI, SQLAlchemy and httpx instrumentation and the request hooks. Telemetry goes only to the
local agent (OTEL_EXPORTER_OTLP_ENDPOINT, default http://127.0.0.1:4318). OW_TELEMETRY=0 turns it all off.
"""
import os
from pathlib import Path

from fastapi import Request
from fastapi.exception_handlers import http_exception_handler, request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from . import ow_payload, ow_security

ENABLED = os.environ.get("OW_TELEMETRY", "1") != "0"
_HERE = Path(__file__).parent


def _commit() -> str:
    c = os.environ.get("GIT_COMMIT", "")
    if not c and (_HERE / "UPSTREAM_COMMIT").exists():
        c = (_HERE / "UPSTREAM_COMMIT").read_text().strip()
    return c


def setup():
    if not ENABLED:
        return
    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://127.0.0.1:4318").rstrip("/")
    resource = Resource.create({
        "service.name": os.environ.get("OTEL_SERVICE_NAME", "fastapi-template"),
        "deployment.environment.name": os.environ.get("OW_ENVIRONMENT", "test"),
        "service.version": os.environ.get("APP_VERSION", "0.1.0"),
        "vcs.repository.url.full": "https://github.com/fastapi/full-stack-fastapi-template",
        "vcs.ref.head.revision": _commit(),
    })
    provider = TracerProvider(resource=resource)
    provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=endpoint + "/v1/traces")))
    trace.set_tracer_provider(provider)
    ow_security.init(resource, endpoint + "/v1/logs")
    print(f"[obsidianwatch] telemetry to {endpoint} as {resource.attributes['service.name']}", flush=True)


def client_of(request: Request) -> str | None:
    return request.client.host if request.client else None


async def capture(request: Request) -> None:
    """Router dependency: client address and request-body field names on the server span."""
    if not ENABLED:
        return
    try:
        from opentelemetry import trace
        span = trace.get_current_span()
        ip = client_of(request)
        if ip:
            span.set_attribute("client.address", ip)
            span.set_attribute("network.peer.address", ip)
        ct = request.headers.get("content-type", "").lower()
        if request.method in ("POST", "PUT", "PATCH"):
            if "application/json" in ct:
                body = await request.json()
                ow_payload.set_body(body if isinstance(body, dict) else None)
            elif "application/x-www-form-urlencoded" in ct:
                ow_payload.set_body(dict((await request.form()).items()))
    except Exception:
        pass  # observability must never break a request


def route_of(request: Request) -> str:
    r = request.scope.get("route")
    return getattr(r, "path", None) or request.url.path


def instrument(app, engine):
    if not ENABLED:
        return
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
    from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
    from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor

    FastAPIInstrumentor.instrument_app(app, exclude_spans=["receive", "send"])
    SQLAlchemyInstrumentor().instrument(engine=engine)
    HTTPXClientInstrumentor().instrument()

    @app.exception_handler(StarletteHTTPException)
    async def _ow_http(request: Request, exc: StarletteHTTPException):
        if exc.status_code in (401, 403) and not route_of(request).endswith("/login/access-token"):
            ow_security.authz_denied("api", request.method.lower(), route=route_of(request), client=client_of(request))
        return await http_exception_handler(request, exc)

    @app.exception_handler(RequestValidationError)
    async def _ow_invalid(request: Request, exc: RequestValidationError):
        for err in exc.errors()[:3]:
            loc = [str(x) for x in err.get("loc", ()) if x not in ("body", "query", "path")]
            ow_security.input_rejected("validation", route=route_of(request), parameter=".".join(loc) or None,
                                       client=client_of(request))
        return await request_validation_exception_handler(request, exc)


# Thin wrappers the routes call; no-ops when telemetry is off.
def login(request, outcome, user=None, reason=None):
    if ENABLED:
        ow_security.login(outcome, user=user, client=client_of(request), route=route_of(request), method="password", reason=reason)


def admin(request, action, user=None, target_type="user", target_id=None, outcome="success"):
    if ENABLED:
        ow_security.admin_action(action, user=user, target_type=target_type, target_id=str(target_id) if target_id else None,
                                 outcome=outcome, route=route_of(request), client=client_of(request))


def export(request, object_type, rows, user=None):
    if ENABLED:
        ow_security.data_export(object_type, user=user, format="json", rows=rows, route=route_of(request), client=client_of(request))


def access(request, object_type, object_id, user=None):
    if ENABLED:
        ow_security.data_access(object_type, str(object_id), user=user, route=route_of(request), client=client_of(request))


def rate_limited(request, name):
    if ENABLED:
        ow_security.rate_limited(name, route=route_of(request), client=client_of(request))
