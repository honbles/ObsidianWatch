/*
 * Copyright (c) 2014-2026 Bjoern Kimminich & the OWASP Juice Shop contributors.
 * SPDX-License-Identifier: MIT
 */

export interface Review {
  _id: string
  message: string
  author: string
  likesCount?: number
  liked?: boolean
  likedBy?: string[]
}
