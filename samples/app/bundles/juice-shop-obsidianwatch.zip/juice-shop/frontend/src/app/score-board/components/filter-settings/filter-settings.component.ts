import { Component, EventEmitter, Input, type OnChanges, type OnInit, Output, inject, ChangeDetectionStrategy } from '@angular/core'
import { FilterSetting } from '../../filter-settings/FilterSetting'
import { type EnrichedChallenge } from '../../types/EnrichedChallenge'
import { MatDialog } from '@angular/material/dialog'
import { ScoreBoardAdditionalSettingsDialogComponent } from './components/score-board-additional-settings-dialog/score-board-additional-settings-dialog.component'
import { DifficultySelectionSummaryPipe } from './pipes/difficulty-selection-summary.pipe'
import { CategoryFilterComponent } from './components/category-filter/category-filter.component'
import { MatTooltip } from '@angular/material/tooltip'
import { MatIconButton } from '@angular/material/button'
import { DifficultyStarsComponent } from '../difficulty-stars/difficulty-stars.component'
import { MatOption, MatOptgroup } from '@angular/material/core'
import { TagsService } from '../../../Services/tags.service'

import { MatSelect, MatSelectTrigger } from '@angular/material/select'
import { MatInputModule } from '@angular/material/input'
import { TranslateModule } from '@ngx-translate/core'
import { MatIconModule } from '@angular/material/icon'
import { MatFormFieldModule, MatPrefix, MatLabel } from '@angular/material/form-field'

export const OTHER_TAG_GROUP = 'Other'

export interface TagGroup {
  name: string
  tags: string[]
}

@Component({
  changeDetection: ChangeDetectionStrategy.Eager,
  selector: 'filter-settings',
  templateUrl: './filter-settings.component.html',
  styleUrls: ['./filter-settings.component.scss'],
  imports: [MatFormFieldModule, MatIconModule, MatPrefix, MatLabel, TranslateModule, MatInputModule, MatSelect, MatSelectTrigger, MatOption, MatOptgroup, DifficultyStarsComponent, MatIconButton, MatTooltip, CategoryFilterComponent, DifficultySelectionSummaryPipe]
})
export class FilterSettingsComponent implements OnChanges, OnInit {
  private readonly dialog = inject(MatDialog)
  private readonly tagsService = inject(TagsService)

  @Input()
  public allChallenges: EnrichedChallenge[]

  @Input()
  public filterSetting: FilterSetting

  @Output()
  public filterSettingChange = new EventEmitter<FilterSetting>()

  @Input()
  public reset: () => void

  public static readonly EXTERNAL_DEPENDENCY_TAG = 'External Dependency'
  public tags: string[] = []
  public tagGroups: TagGroup[] = []
  private tagToGroupName: Record<string, string> = {}

  ngOnInit () {
    this.tagsService.getTagGroups().subscribe((tagGroups) => {
      this.tagToGroupName = {}
      for (const [groupName, tags] of Object.entries(tagGroups)) {
        for (const tag of tags) {
          this.tagToGroupName[tag] = groupName
        }
      }
      if (this.allChallenges) {
        this.ngOnChanges()
      }
    })
  }

  ngOnChanges () {
    const rawTags = new Set(
      this.allChallenges.flatMap((challenge) => challenge.tagList)
    )
    const hasRequiresTag = [...rawTags].some((tag) => tag.startsWith('Requires '))
    const displayTags = new Set<string>()
    for (const tag of rawTags) {
      if (tag.startsWith('Requires ')) {
        if (hasRequiresTag) {
          displayTags.add(FilterSettingsComponent.EXTERNAL_DEPENDENCY_TAG)
        }
      } else {
        displayTags.add(tag)
      }
    }
    this.tags = [...displayTags].sort((a, b) => a.localeCompare(b))

    const groupsMap = new Map<string, string[]>()
    for (const tag of displayTags) {
      const groupName = this.tagToGroupName[tag] ?? OTHER_TAG_GROUP
      if (!groupsMap.has(groupName)) {
        groupsMap.set(groupName, [])
      }
      groupsMap.get(groupName)!.push(tag)
    }

    this.tagGroups = [...groupsMap.entries()]
      .map(([name, tags]) => ({
        name,
        tags: tags.sort((a, b) => a.localeCompare(b))
      }))
      .sort((a, b) => a.name.localeCompare(b.name))
  }

  onDifficultyFilterChange (difficulties: (1 | 2 | 3 | 4 | 5 | 6)[]) {
    const filterSettingCopy = structuredClone(this.filterSetting)
    filterSettingCopy.difficulties = difficulties
    this.filterSettingChange.emit(filterSettingCopy)
  }

  onStatusFilterChange (status: 'solved' | 'unsolved' | null) {
    const filterSettingCopy = structuredClone(this.filterSetting)
    filterSettingCopy.status = status
    this.filterSettingChange.emit(filterSettingCopy)
  }

  onTagFilterChange (tags: string[]) {
    const filterSettingCopy = structuredClone(this.filterSetting)
    filterSettingCopy.tags = tags
    this.filterSettingChange.emit(filterSettingCopy)
  }

  onCategoryFilterChange (categories: string[]) {
    const filterSettingCopy = structuredClone(this.filterSetting)
    filterSettingCopy.categories = categories
    this.filterSettingChange.emit(filterSettingCopy)
  }

  onSearchQueryFilterChange (searchQuery: string) {
    const filterSettingCopy = structuredClone(this.filterSetting)
    filterSettingCopy.searchQuery = searchQuery
    this.filterSettingChange.emit(filterSettingCopy)
  }

  public canBeReset (): boolean {
    const nonDefaultFilters = [
      this.filterSetting.difficulties.length > 0,
      this.filterSetting.status !== null,
      this.filterSetting.tags.length > 0,
      this.filterSetting.categories.length > 0,
      !!this.filterSetting.searchQuery,
      !this.filterSetting.showDisabledChallenges
    ]
    return nonDefaultFilters.some(Boolean)
  }

  public openAdditionalSettingsDialog () {
    this.dialog.open(ScoreBoardAdditionalSettingsDialogComponent)
  }
}
