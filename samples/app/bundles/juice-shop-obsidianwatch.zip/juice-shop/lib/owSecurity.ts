/*
 * ObsidianWatch bridge: Juice Shop's code reports security events and request-body fields through this module.
 * ow/instrumentation.js (loaded with --require) puts the helpers on globalThis; without it every call is a no-op.
 * See docs/application/configuration-node.md in ObsidianWatch.
 */
import { type Request, type Response, type NextFunction } from 'express'

const ow = (): any => (globalThis as any).__obsidianwatch

const clientOf = (req: Request): string | undefined => req.socket?.remoteAddress ?? undefined
const routeOf = (req: Request): string => (req.route?.path ? (req.baseUrl || '') + String(req.route.path) : String(req.originalUrl || req.url || '').split('?')[0])
const call = (name: string, ...args: any[]) => { try { ow()?.security?.[name]?.(...args) } catch { /* never affect a request */ } }

export const owLogin = (req: Request, outcome: 'success' | 'failure', reason?: string, mfa?: string) =>
  call('login', outcome, { user: req.body?.email, client: clientOf(req), route: routeOf(req), method: 'password', reason, mfa })
export const owMfa = (req: Request, outcome: 'success' | 'failure', reason?: string) =>
  call('mfa', outcome, { client: clientOf(req), route: routeOf(req), method: 'totp', reason })
export const owInputRejected = (req: Request, kind: string, parameter?: string) =>
  call('inputRejected', kind, { route: routeOf(req), parameter, client: clientOf(req) })
export const owDataExport = (req: Request, objectType: string, format: string, rows?: number) =>
  call('dataExport', objectType, { format, rows, route: routeOf(req), client: clientOf(req) })

// Request-body fields: after the body parsers.
export function owPayload (req: Request, res: Response, next: NextFunction) {
  try { ow()?.payload?.record(req, req.body) } catch { /* ignore */ }
  next()
}

// Authorization: every 401 or 403 answered on a route other than login (where the login event says it).
export function owAuthzDenied (req: Request, res: Response, next: NextFunction) {
  res.once('finish', () => {
    if ((res.statusCode === 401 || res.statusCode === 403) && !/\/rest\/user\/login|\/rest\/2fa\/verify/.test(req.originalUrl || '')) {
      call('authzDenied', 'route', req.method, { route: routeOf(req), client: clientOf(req), policy: res.statusCode === 401 ? 'authentication_required' : 'forbidden' })
    }
  })
  next()
}
