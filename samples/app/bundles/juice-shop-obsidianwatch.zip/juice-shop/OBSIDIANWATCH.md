# OWASP Juice Shop, instrumented for ObsidianWatch (Node.js, Tier 2)

Upstream: https://github.com/juice-shop/juice-shop at commit in `ow/UPSTREAM_COMMIT` (v20.4.0-SNAPSHOT).
Juice Shop is deliberately vulnerable: run it on a test machine only, never on the internet.

## Run
    ./run.sh               # installs what is missing, starts on a random free port on 0.0.0.0, prints the URL
    ./run.sh traffic       # in a second terminal: logins, SQL injection, bad 2FA, denied calls, data export
    PORT=3000 ./run.sh     # fixed port;  HOST=127.0.0.1 ./run.sh to bind loopback only

Needs Node 22.15+ (22 or 24), npm, and a C toolchain (build-essential, python3) for sqlite3.
The server (`build/`) and the web UI (`frontend/dist/`) are prebuilt, so the first run only installs
`node_modules` (`npm install --omit=dev`) and builds sqlite3. Telemetry goes to the agent at
`OTEL_EXPORTER_OTLP_ENDPOINT` (default http://127.0.0.1:4318). Service name `juice-shop`, environment `test`
(override with OTEL_SERVICE_NAME, OW_ENVIRONMENT).

## What was changed (all marked; grep for "ObsidianWatch" / "ow")
- `ow/instrumentation.js` — loaded with `--require`: NodeSDK, auto-instrumentations (http, express, ...),
  resource with service name, environment, version, `vcs.repository.url.full` and `vcs.ref.head.revision`
  (the commit), payload field capture (`ow-payload.js`), the security helper (`ow-security.js`), and a
  CLIENT span around `Sequelize.prototype.query` (SQLite has no OpenTelemetry instrumentation).
- `lib/owSecurity.ts` — bridge used by the routes; a no-op when the preload is absent.
- `routes/login.ts` — auth.login success/failure (+ input.rejected on SQL errors from the email field).
- `routes/2fa.ts` — auth.mfa; `routes/dataExport.ts` — data.export.
- `server.ts` — authz.deny on 401/403, request-body field capture after the JSON parser, listen on 0.0.0.0.
- `frontend/angular.json` — font inlining off (the build otherwise downloads Google Fonts).
- `package.json` — OpenTelemetry dependencies.

## What to look at in ObsidianWatch (Applications -> Services -> juice-shop)
Tier 2 badge; Endpoints (`POST /rest/user/login`, `/api/Users`, ...); Queries (fingerprinted SQLite statements,
including the injected `email = ? or ?=?` shape); Errors; Security (auth.login, auth.mfa, authz.deny,
input.rejected, data.export); Instances (verified, version 20.4.0-SNAPSHOT, the upstream commit); Events
(search `app:juice-shop`).
