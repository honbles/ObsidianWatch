'use strict'
// ObsidianWatch instrumentation for OWASP Juice Shop, loaded before the app:  node --require ./ow/instrumentation.js build/app.js
// (run.sh does this). It follows docs/application/configuration-node.md:
//   - OpenTelemetry auto-instrumentation (HTTP server and clients, Express routes) to the local agent;
//   - request-body field capture (ow-payload.js; Juice Shop calls its middleware after its body parsers);
//   - the security helper (ow-security.js; Juice Shop's login, 2FA, export and authorization code calls it
//     through lib/owSecurity.ts), which makes the service Tier 2;
//   - database spans for Sequelize (Juice Shop's ORM on SQLite has no OpenTelemetry instrumentation), so the
//     Queries tab fills: each query is a client span with db.system and the statement;
//   - the commit and repository as resource attributes, so the Code tab knows what runs.
// Env: OTEL_EXPORTER_OTLP_ENDPOINT (default http://127.0.0.1:4318), OTEL_SERVICE_NAME (juice-shop),
//      OW_ENVIRONMENT (default "test"), OW_SECURITY_CONSOLE=1 prints each security event.
const path = require('path')
const fs = require('fs')
if (process.env.OW_PRELOADED === '1') return // Juice Shop's child processes: one SDK per service
process.env.OW_PRELOADED = '1'

const api = require('@opentelemetry/api')
const { NodeSDK } = require('@opentelemetry/sdk-node')
const { getNodeAutoInstrumentations } = require('@opentelemetry/auto-instrumentations-node')
const { OTLPTraceExporter } = require('@opentelemetry/exporter-trace-otlp-http')
const resources = require('@opentelemetry/resources')
const security = require('./ow-security')
const payload = require('./ow-payload')

const root = path.resolve(__dirname, '..')
const endpoint = (process.env.OTEL_EXPORTER_OTLP_ENDPOINT || 'http://127.0.0.1:4318').replace(/\/$/, '')
const read = (f) => { try { return fs.readFileSync(path.join(__dirname, f), 'utf8').trim() } catch { return '' } }
const attrs = {
  'service.name': process.env.OTEL_SERVICE_NAME || 'juice-shop',
  'deployment.environment.name': process.env.OW_ENVIRONMENT || 'test',
  'service.version': require(path.join(root, 'package.json')).version,
  'vcs.repository.url.full': 'https://github.com/juice-shop/juice-shop',
}
if (read('UPSTREAM_COMMIT').length === 40) attrs['vcs.ref.head.revision'] = read('UPSTREAM_COMMIT')
const resource = resources.resourceFromAttributes ? resources.resourceFromAttributes(attrs) : new resources.Resource(attrs)

const sdk = new NodeSDK({
  resource,
  traceExporter: new OTLPTraceExporter({ url: endpoint + '/v1/traces' }),
  instrumentations: [getNodeAutoInstrumentations({
    '@opentelemetry/instrumentation-http': { requestHook: payload.requestHook },
    '@opentelemetry/instrumentation-fs': { enabled: false }, // Juice Shop reads many files; fs spans are noise
  })],
})
sdk.start()

const logsProvider = security.init(resource, endpoint + '/v1/logs')
// Juice Shop's code reaches the helpers through lib/owSecurity.ts, which does nothing when this file is not loaded.
globalThis.__obsidianwatch = { security, payload }

// Database spans: wrap Sequelize's query(). Every model call and raw query goes through it.
try {
  const { Sequelize } = require(require.resolve('sequelize', { paths: [root] }))
  const tracer = api.trace.getTracer('juice-shop-db')
  const orig = Sequelize.prototype.query
  Sequelize.prototype.query = function (sql, options) {
    const text = typeof sql === 'string' ? sql : (sql && sql.query) || ''
    const span = tracer.startSpan('db ' + (text.trim().split(/\s+/)[0] || 'query').toUpperCase(), {
      kind: api.SpanKind.CLIENT,
      attributes: { 'db.system': 'sqlite', 'db.query.text': String(text).slice(0, 2000) },
    })
    const done = (err) => {
      if (err) { span.recordException(err); span.setStatus({ code: api.SpanStatusCode.ERROR, message: String(err.message || err) }) }
      span.end()
    }
    let p
    try { p = api.context.with(api.trace.setSpan(api.context.active(), span), () => orig.apply(this, arguments)) } catch (e) { done(e); throw e }
    return Promise.resolve(p).then((r) => { done(); return r }, (e) => { done(e); throw e })
  }
} catch (e) {
  process.stderr.write('[obsidianwatch] database spans not enabled: ' + e.message + '\n')
}

let closing = false
const flush = () => Promise.allSettled([sdk.shutdown(), logsProvider && logsProvider.shutdown()])
function onSignal(sig) {
  if (closing) return
  closing = true
  const exit = () => process.exit(0)
  flush().then(exit, exit)
  setTimeout(exit, 3000).unref()
}
process.on('SIGTERM', onSignal)
process.on('SIGINT', onSignal)
process.stderr.write(`[obsidianwatch] telemetry to ${endpoint} as ${attrs['service.name']} (${attrs['deployment.environment.name']})\n`)
