#!/usr/bin/env bash
# Run OWASP Juice Shop instrumented for ObsidianWatch (Node.js, Tier 2).
#
#   ./run.sh            install what is missing, then start on a random free port on 0.0.0.0
#   PORT=3000 ./run.sh  a fixed port instead
#   ./run.sh traffic    send sample traffic (logins, a SQL injection, 2FA, denied requests, data export) to the running app
#
# Telemetry goes to the ObsidianWatch agent on this host (OTEL_EXPORTER_OTLP_ENDPOINT, default http://127.0.0.1:4318;
# the agent needs the app-server profile). Needs Node 22.15+ (22 or 24), npm, git, a C toolchain for sqlite3.
# SAFETY: Juice Shop is deliberately vulnerable. Run it on a test machine and do not expose the port to the internet.
set -euo pipefail
cd "$(dirname "$0")"
export OTEL_EXPORTER_OTLP_ENDPOINT="${OTEL_EXPORTER_OTLP_ENDPOINT:-http://127.0.0.1:4318}"
export OTEL_SERVICE_NAME="${OTEL_SERVICE_NAME:-juice-shop}"
export OW_ENVIRONMENT="${OW_ENVIRONMENT:-test}"
STATE=.ow-run; mkdir -p "$STATE"

install() {
  if [ ! -d node_modules/@opentelemetry/sdk-node ] || ! node -e "require('sqlite3')" 2>/dev/null; then
    echo "== installing dependencies (a few minutes the first time)"
    CYPRESS_INSTALL_BINARY=0 npm install --omit=dev --ignore-scripts --no-audit --no-fund
    npm rebuild sqlite3
    node -e "require('sqlite3')" || { echo "sqlite3 did not build: install build-essential/python3 and run again"; exit 1; }
  fi
  if [ ! -f build/app.js ] || [ -n "$(find routes lib server.ts -newer build/app.js -name '*.ts' 2>/dev/null | head -1)" ]; then
    echo "== building the server"
    [ -x node_modules/.bin/tsc ] || npm install --no-save --no-audit --no-fund typescript
    npm run build:server >/dev/null 2>&1 || true
    [ -f build/app.js ] || { echo "server build failed: run 'npm run build:server' to see why"; exit 1; }
  fi
  if [ ! -f frontend/dist/frontend/index.html ]; then
    echo "== building the web UI (several minutes)"
    (cd frontend && npm install --no-audit --no-fund --legacy-peer-deps && npm run build)
  fi
}

free_port() { node -e "const s=require('net').createServer().listen(0,'0.0.0.0',()=>{console.log(s.address().port);s.close()})"; }

traffic() {
  local base="http://127.0.0.1:$(cat "$STATE/port")" c=0
  echo "== sending traffic to $base"
  for p in apple banana juice "'))--" ; do curl -s -o /dev/null "$base/rest/products/search?q=$p"; done
  for i in $(seq 1 12); do curl -s -o /dev/null -X POST -H 'Content-Type: application/json' -d "{\"email\":\"user$i@juice-sh.op\",\"password\":\"wrong$i\"}" "$base/rest/user/login"; done
  curl -s -o /dev/null -X POST -H 'Content-Type: application/json' -d "{\"email\":\"' OR 1=1 --\",\"password\":\"x\"}" "$base/rest/user/login"
  curl -s -o /dev/null -X POST -H 'Content-Type: application/json' -d "{\"email\":\"'))\",\"password\":\"x\"}" "$base/rest/user/login"
  local tok; tok=$(curl -s -X POST -H 'Content-Type: application/json' -d '{"email":"jim@juice-sh.op","password":"ncc-1701"}' "$base/rest/user/login" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{try{console.log(JSON.parse(d).authentication.token)}catch{console.log('')}})")
  curl -s -o /dev/null -X POST -H 'Content-Type: application/json' -d '{"tmpToken":"x","totpToken":"000000"}' "$base/rest/2fa/verify"
  for u in /rest/admin/application-configuration /api/Users /rest/user/whoami /api/Feedbacks; do curl -s -o /dev/null -H "Authorization: Bearer invalid" "$base$u"; done
  for u in /api/Users /api/Challenges /api/Quantitys /rest/basket/1; do curl -s -o /dev/null "$base$u"; done
  if [ -n "$tok" ]; then
    curl -s -o /dev/null -H "Authorization: Bearer $tok" "$base/rest/user/whoami"
    curl -s -o /dev/null -X POST -H "Authorization: Bearer $tok" -H 'Content-Type: application/json' -d '{"format":"1"}' "$base/rest/user/data-export"
    curl -s -o /dev/null -X POST -H "Authorization: Bearer $tok" -H 'Content-Type: application/json' -d '{"comment":"great","rating":5}' "$base/api/Feedbacks"
  fi
  echo "done: check Application → Services → $OTEL_SERVICE_NAME (Endpoints, Queries, Security, Events) in a minute"
}

if [ "${1:-}" = "traffic" ]; then traffic; exit 0; fi
install
PORT="${PORT:-$(free_port)}"
echo "$PORT" > "$STATE/port"
export PORT
echo "== Juice Shop on http://0.0.0.0:$PORT  (this host: http://127.0.0.1:$PORT), telemetry to $OTEL_EXPORTER_OTLP_ENDPOINT"
echo "   send traffic from another terminal: ./run.sh traffic"
exec node --require ./ow/instrumentation.js build/app.js
