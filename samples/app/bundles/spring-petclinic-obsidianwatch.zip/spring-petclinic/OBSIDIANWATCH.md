# Spring PetClinic, instrumented for ObsidianWatch (Java, Tier 2)

Upstream: https://github.com/spring-projects/spring-petclinic at the commit in `ow/UPSTREAM_COMMIT`
(Spring Boot 4.2, version 4.0.0-SNAPSHOT, H2 in-memory database).

## Run
    ./run.sh               # builds if needed (./mvnw), starts with the OpenTelemetry Java agent on a random port on 0.0.0.0
    ./run.sh traffic       # second terminal: owners, pets, visits, invalid forms, /oups crash, a missing owner
    PORT=8080 ./run.sh     # fixed port;  HOST=127.0.0.1 ./run.sh to bind loopback only

Needs Java 17+, curl, and internet access to Maven Central for the first build. The OpenTelemetry Java agent
2.34.0 is downloaded into `ow/` from GitHub releases on the first run. Upstream's style gates (spring-javaformat, checkstyle/nohttp,
jacoco, cyclonedx) are skipped by run.sh; tests are skipped.
Telemetry: agent at `OTEL_EXPORTER_OTLP_ENDPOINT` (default http://127.0.0.1:4318), service `petclinic`,
environment `test` (OTEL_SERVICE_NAME, OW_ENVIRONMENT). Traces, helper logs and JVM metrics all over
http/protobuf; version, repository and commit go in OTEL_RESOURCE_ATTRIBUTES.

## What was changed (marked "ObsidianWatch")
- `pom.xml` — `io.opentelemetry:opentelemetry-api` (version from the Spring Boot BOM) for the helper.
- `ow/OwSecurity.java` (package `org.springframework.samples.petclinic.ow`) — the helper from samples/app/java.
- `ow/OwRequestFilter.java` — servlet filter: client address and submitted form field names on the server span
  (`ow.request.body`), 401/403 -> authz.deny.
- `ow/Ow.java` — calls used by the controllers: input.rejected per invalid form field, admin.action for
  owner/pet/visit create and update, data.export for owner lists, data.access for an owner's page.
- `owner/OwnerController.java`, `PetController.java`, `VisitController.java` — one-line calls to `Ow`.
PetClinic has no login, so there are no auth.login events; the other helper events make the service Tier 2.

## What to look at (Applications -> Services -> petclinic)
Tier 2; Endpoints (`/owners/{ownerId}`, `/owners/{ownerId}/pets/new` ...); Queries (JDBC on H2, fingerprinted);
Errors (`RuntimeException` from `/oups`, `IllegalArgumentException` for a missing owner); runtime (JVM heap, CPU,
Hikari pool); Security; Instances (verified, `java`, version 4.0.0-SNAPSHOT, the upstream commit).

## Test status
This bundle could not be built in the environment it was prepared in (Maven Central was unreachable there).
The new classes were compiled against stand-ins for the servlet, Spring and OpenTelemetry types, and the
OpenTelemetry Java agent 2.34.0 with these exact settings was run against the ObsidianWatch agent (service,
routes, verified instance and JVM metrics arrived). If the build reports an error, send the output.
