package org.springframework.samples.petclinic.ow;

import java.io.IOException;
import java.util.Map;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import io.opentelemetry.api.trace.Span;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * ObsidianWatch request hook: puts the client address and the names of submitted form fields on the
 * server span the OpenTelemetry Java agent created, keeps the request for {@link Ow}, and reports 401
 * and 403 answers as authz.deny. Field values are sent to the local agent, which forwards names only
 * (values only for routes an admin reviewed, never deny-listed fields such as passwords).
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class OwRequestFilter implements Filter {

	private static final int MAX_BODY = 32 * 1024;

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		if (!(req instanceof HttpServletRequest request) || !(res instanceof HttpServletResponse response)) {
			chain.doFilter(req, res);
			return;
		}
		Ow.CURRENT.set(request);
		try {
			tag(request);
			chain.doFilter(req, res);
		}
		finally {
			Ow.CURRENT.remove();
			int status = response.getStatus();
			if (status == 401 || status == 403) {
				try {
					OwSecurity.authzDenied("page", request.getMethod().toLowerCase(), null, Ow.route(request),
							request.getRemoteAddr());
				}
				catch (RuntimeException ex) {
					// never break a request
				}
			}
		}
	}

	private static void tag(HttpServletRequest request) {
		try {
			Span span = Span.current();
			span.setAttribute("client.address", request.getRemoteAddr());
			span.setAttribute("network.peer.address", request.getRemoteAddr());
			String ct = request.getContentType();
			if ("POST".equals(request.getMethod()) && ct != null
					&& ct.toLowerCase().startsWith("application/x-www-form-urlencoded")) {
				String body = json(request.getParameterMap());
				if (body.length() > 2 && body.length() <= MAX_BODY) {
					span.setAttribute("ow.request.body", body);
				}
			}
		}
		catch (RuntimeException ex) {
			// never break a request
		}
	}

	/** The form as a flat JSON object (first value of each field). */
	static String json(Map<String, String[]> params) {
		StringBuilder b = new StringBuilder("{");
		for (Map.Entry<String, String[]> e : params.entrySet()) {
			if (b.length() > 1) {
				b.append(',');
			}
			String[] v = e.getValue();
			b.append(quote(e.getKey())).append(':').append(quote((v != null && v.length > 0) ? v[0] : ""));
		}
		return b.append('}').toString();
	}

	static String quote(String s) {
		StringBuilder b = new StringBuilder("\"");
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			switch (c) {
				case '"' -> b.append("\\\"");
				case '\\' -> b.append("\\\\");
				case '\n' -> b.append("\\n");
				case '\r' -> b.append("\\r");
				case '\t' -> b.append("\\t");
				default -> {
					if (c < 0x20) {
						b.append(String.format("\\u%04x", (int) c));
					}
					else {
						b.append(c);
					}
				}
			}
		}
		return b.append('"').toString();
	}

}
