package org.springframework.samples.petclinic.ow;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

/**
 * ObsidianWatch calls used by the petclinic controllers. The request of the current thread is set by
 * {@link OwRequestFilter}, so callers pass only what the event is about. Every call is safe when the
 * OpenTelemetry Java agent is absent: the API then has no implementation and the events go nowhere.
 */
public final class Ow {

	static final ThreadLocal<HttpServletRequest> CURRENT = new ThreadLocal<>();

	// Spring MVC stores the matched route template in this request attribute
	// (HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE).
	static final String ROUTE_ATTR = "org.springframework.web.servlet.HandlerMapping.bestMatchingPattern";

	private Ow() {
	}

	static String route(HttpServletRequest r) {
		if (r == null) {
			return null;
		}
		Object p = r.getAttribute(ROUTE_ATTR);
		return (p != null) ? p.toString() : r.getRequestURI();
	}

	private static String route() {
		return route(CURRENT.get());
	}

	private static String client() {
		HttpServletRequest r = CURRENT.get();
		return (r != null) ? r.getRemoteAddr() : null;
	}

	private static void safe(Runnable r) {
		try {
			r.run();
		}
		catch (RuntimeException ex) {
			// observability must never break a request
		}
	}

	/** A form failed validation: one input.rejected event per field (at most three). */
	public static void rejected(List<String> fields) {
		safe(() -> {
			int n = 0;
			for (String f : fields) {
				if (n++ == 3) {
					break;
				}
				OwSecurity.inputRejected("validation", route(), f, client());
			}
		});
	}

	/** A record was created or changed through the admin forms. */
	public static void changed(String action, String targetType, Object targetId) {
		safe(() -> OwSecurity.adminAction(action, null, targetType, (targetId != null) ? targetId.toString() : null,
				client()));
	}

	/** A list of records was returned. */
	public static void listed(String objectType, long rows) {
		safe(() -> OwSecurity.dataExport(objectType, null, "html", Long.toString(rows), route(), client()));
	}

	/** One record was read. */
	public static void viewed(String objectType, Object id) {
		safe(() -> OwSecurity.dataAccess(objectType, String.valueOf(id), null, route(), client()));
	}

}
