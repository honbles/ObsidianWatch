#!/usr/bin/env bash
# Run Spring PetClinic instrumented for ObsidianWatch (Java, Tier 2).
#
#   ./run.sh            build if needed, start on a random free port on 0.0.0.0 with the OpenTelemetry Java agent
#   PORT=8080 ./run.sh  a fixed port;  HOST=127.0.0.1 ./run.sh  loopback only
#   ./run.sh traffic    send sample traffic (owners, pets, visits, bad forms, a crash, odd query strings)
#
# Needs Java 17+ and internet access to Maven Central for the first build (./mvnw fetches Maven itself).
# The OpenTelemetry Java agent 2.34.0 is downloaded into ow/ from GitHub releases on the first run.
# Database: the built-in H2 in-memory database. Telemetry: OTEL_EXPORTER_OTLP_ENDPOINT (default http://127.0.0.1:4318).
set -euo pipefail
cd "$(dirname "$0")"
STATE=.ow-run; mkdir -p "$STATE"
AGENT_VERSION=2.34.0
export OTEL_EXPORTER_OTLP_ENDPOINT="${OTEL_EXPORTER_OTLP_ENDPOINT:-http://127.0.0.1:4318}"
export OTEL_SERVICE_NAME="${OTEL_SERVICE_NAME:-petclinic}"
ENVIRONMENT="${OW_ENVIRONMENT:-test}"
free_port() { python3 -c "import socket;s=socket.socket();s.bind(('0.0.0.0',0));print(s.getsockname()[1]);s.close()" 2>/dev/null \
  || echo $(( 20000 + RANDOM % 40000 )); }

traffic() {
  local base="http://127.0.0.1:$(cat "$STATE/port")" c="curl -s -o /dev/null"
  echo "== sending traffic to $base"
  for p in / /vets.html /owners/find "/owners?lastName=" "/owners?lastName=Davis" "/owners?lastName=%27%20OR%201%3D1--" /owners/1 /owners/2 /owners/3/edit /owners/1/pets/new; do $c "$base$p"; done
  for i in 1 2 3; do $c -X POST -d "firstName=&lastName=&address=&city=&telephone=abc" "$base/owners/new"; done        # validation errors
  $c -X POST -d "firstName=Ada&lastName=Lovelace$RANDOM&address=1 Analytical St&city=London&telephone=0123456789" "$base/owners/new"
  $c -X POST -d "firstName=George&lastName=Franklin&address=110 W. Liberty St.&city=Madison&telephone=6085551023" "$base/owners/1/edit"
  $c -X POST -d "name=Rex$RANDOM&birthDate=2020-01-01&type=dog" "$base/owners/1/pets/new"
  $c -X POST -d "name=&birthDate=2999-01-01&type=dog" "$base/owners/1/pets/new"                                     # bad pet form
  $c -X POST -d "date=2999-12-31&description=checkup" "$base/owners/1/pets/1/visits/new"
  for i in 1 2 3; do $c "$base/oups"; done                                                                              # deliberate crash: error group
  $c "$base/owners/99999"                                                                                                 # missing owner: error
  $c "$base/actuator/health"
  echo "done: check Application -> Services -> $OTEL_SERVICE_NAME in a minute"
}

if [ "${1:-}" = "traffic" ]; then traffic; exit 0; fi
command -v java >/dev/null || { echo "Java 17 or later is required"; exit 1; }
if [ ! -f ow/opentelemetry-javaagent.jar ]; then
  echo "== downloading the OpenTelemetry Java agent $AGENT_VERSION"
  curl -fL -o ow/opentelemetry-javaagent.jar "https://github.com/open-telemetry/opentelemetry-java-instrumentation/releases/download/v$AGENT_VERSION/opentelemetry-javaagent.jar"
fi
JAR=$(ls target/spring-petclinic-*.jar 2>/dev/null | grep -v plain | head -1 || true)
if [ -z "$JAR" ] || [ -n "$(find src pom.xml -newer "$JAR" -type f 2>/dev/null | head -1)" ]; then
  echo "== building (first time: several minutes, downloads dependencies from Maven Central)"
  # Upstream's format and checkstyle checks are skipped: they are style gates for contributors, not for running.
  ./mvnw -q -B -DskipTests -Dcheckstyle.skip=true -Dspring-javaformat.skip=true -Djacoco.skip=true -Dcyclonedx.skip=true package
  JAR=$(ls target/spring-petclinic-*.jar | grep -v plain | head -1)
fi
COMMIT=$(cat ow/UPSTREAM_COMMIT)
VERSION=$(sed -n 's:^  <version>\(.*\)</version>:\1:p' pom.xml | head -1)
export OTEL_RESOURCE_ATTRIBUTES="deployment.environment.name=$ENVIRONMENT,service.version=${VERSION:-0},vcs.repository.url.full=https://github.com/spring-projects/spring-petclinic,vcs.ref.head.revision=$COMMIT${OTEL_RESOURCE_ATTRIBUTES:+,$OTEL_RESOURCE_ATTRIBUTES}"
export OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf OTEL_TRACES_EXPORTER=otlp OTEL_LOGS_EXPORTER=otlp OTEL_METRICS_EXPORTER=otlp
PORT="${PORT:-$(free_port)}"; echo "$PORT" > "$STATE/port"
echo "== PetClinic on http://${HOST:-0.0.0.0}:$PORT, telemetry to $OTEL_EXPORTER_OTLP_ENDPOINT as $OTEL_SERVICE_NAME ($ENVIRONMENT)"
echo "   send traffic from another terminal: ./run.sh traffic"
exec java -javaagent:ow/opentelemetry-javaagent.jar -jar "$JAR" --server.port="$PORT" --server.address="${HOST:-0.0.0.0}"
